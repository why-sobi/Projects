//============================================================================
// Name        : .cpp
// Author      : Sibt ul Hussain
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Centipede...
//============================================================================

#ifndef CENTIPEDE_CPP_
#define CENTIPEDE_CPP_
#include "util.h"
#include <iostream>
#include <string>
#include <cmath> // for basic math functions such as cos, sin, sqrt
#include "classes.h"
#include <fstream>
using namespace std;

Game ***game = nullptr;
//--------------------------------------------------------------------------------------------------------------------------------//

void SetCanvasSize(int width, int height) // Setting screen size
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void GameDisplay() // Printing everything on screen
{
	static bool direction_y;
	static int direction_x = 0;

	glClearColor(0.0 /*Red Component*/, 0.0,					 // 148.0/255/*Green Component*/,
				 0.0 /*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear(GL_COLOR_BUFFER_BIT);								 // Update the colors

	// DrawCircle(100, 100, 10, colors[RED]);

	// DrawRoundRect(0, 0, 100, 50, colors[DARK_OLIVE_GREEN], 20);
	// DrawRoundRect(100, 100, 50, 100, colors[DARK_OLIVE_GREEN], 30);

	// Borders
	DrawRectangle(0, 0, 5, 600, colors[DARK_SLATE_GRAY]);
	DrawRectangle(800 - 5, 0, 5, 600, colors[DARK_SLATE_GRAY]);
	DrawRectangle(0, 600 - 5, 800, 5, colors[DARK_SLATE_GRAY]);

	if (Game::game_started == 0)
	{
		DrawString(300, 300, "BALL BREAKER", colors[RED]);
		DrawString(300, 200, "Press Space to Start", colors[WHITE]);
		DrawString(10, 550, "Muhammad Soban", colors[RED]);
		DrawString(10, 500, "23i-0056", colors[RED]);
		DrawString(300, 150, "Press 1 for level 1", colors[WHITE]);
		DrawString(300, 120, "Press 2 for level 2", colors[WHITE]);
		DrawString(300, 90, "Press 3 for level 3", colors[WHITE]);
	}
	// Game drawing
	else if (Game::game_started == 1)
	{
		DrawString(600, 650, "Score: ", colors[MISTY_ROSE]);
		DrawString(700, 650, to_string(Game::score), colors[MISTY_ROSE]);
		DrawString(300, 650, "High Score: ", colors[MISTY_ROSE]);
		DrawString(450, 650, to_string(Game::h_score), colors[MISTY_ROSE]);

		int amount_ball = 1; // condition for powerup will happen later
		int amount_pad = (Game::level == 1 || Game::level == 2) ? (1) : (2);
		int amount_brick = (Game::level == 2) ? (18) : (Game::level == 3) ? (20)
																		  : (40);

		for (int i = 0; i < amount_ball; i++)
		{
			int pretty = game[0][i]->get_ball_color();
			DrawCircle((game[0])[i]->get_ballx(), (game[0])[i]->get_bally(), 8, (pretty == 0) ? (colors[GREEN_YELLOW]) : (pretty == 1) ? (colors[DARK_MAGENTA])
																													 : (pretty == 2)   ? colors[YELLOW]
																																	   : (colors[MAGENTA]));
		}
		for (int i = 0; i < amount_pad; i++)
		{
			int pretty = game[1][i]->get_pad_color();
			DrawRectangle(game[1][i]->get_padx(), game[1][i]->get_pady(), game[1][i]->get_pad_l(), game[1][i]->get_pad_w(), (pretty == 0) ? (colors[GREEN_YELLOW]) : (pretty == 1) ? (colors[DARK_MAGENTA])
																																								 : (pretty == 2)   ? colors[YELLOW]
																																												   : (colors[MAGENTA]));
		}

		for (int i = 0; i < amount_brick; i++)
		{
			int pretty = game[2][i]->get_brick_color();
			int life = game[2][i]->get_brick_lives();
			if (life > 0) // only print if it has lives
				DrawRectangle(game[2][i]->get_brickx(), game[2][i]->get_bricky(), game[2][i]->get_brick_l(), game[2][i]->get_brick_w(),
							  (pretty == 0) ? (colors[GREEN_YELLOW]) : (pretty == 1) ? (colors[DARK_MAGENTA])
																   : (pretty == 2)	 ? colors[YELLOW]
																					 : (colors[MAGENTA]));
			else // power-ups
			{
				if (game[2][i]->drop_pwr() && (game[2][i]->get_bricky() >= (game[1][0]->get_pad_w() + game[1][0]->get_pady())))
				{
					Bricks *temp = dynamic_cast<Bricks *>(game[2][i]); // to be able to access it's stuff directly
					int power_type = (temp->brick_pwr).get_pwr_type();
					if (power_type == 1) // increase paddle size
					{
						DrawTriangle(game[2][i]->get_brickx(), game[2][i]->get_bricky(), game[2][i]->get_brickx() + 16, game[2][i]->get_bricky() + 16,
									 game[2][i]->get_brickx() + 32, game[2][i]->get_bricky(), colors[GREEN]);
					}
					else if (power_type == 2) // Decrease paddle size
					{

						DrawSquare(game[2][i]->get_brickx(), game[2][i]->get_bricky(), 10, colors[HOT_PINK]);
					}
					else if (power_type == 3) // Decrease ball speed
					{
						DrawCircle(game[2][i]->get_brickx(), game[2][i]->get_bricky(), 10, colors[BLUE]);
					}
					else if (power_type == 4) // Increase ball speed
					{
						DrawSquare(game[2][i]->get_brickx(), game[2][i]->get_bricky(), 10, colors[RED]);
						DrawSquare(game[2][i]->get_brickx(), game[2][i]->get_bricky() + 10, 10, colors[RED]);
					}
					else if (power_type == 5) // Multiply Balls
					{
						DrawSquare(game[2][i]->get_brickx(), game[2][i]->get_bricky(), 10, colors[YELLOW]);
					}

					game[2][i]->set_bricky(game[2][i]->get_bricky() - 3);
				}
			}
		}

		// Collision between paddle and brick (now power-up)
		int pad_height = (game[1][0]->get_pady() + game[1][0]->get_pad_w());

		for (int i = 0; i < amount_brick; i++)
		{
			if (game[2][i]->get_brick_lives() != 0) // The brick has not been broken yet
			{
				continue;
			}
			else if (game[2][i]->get_brick_drop() != 1 && game[2][i]->get_brick_drop() != 2) // There is no drop in the brick
			{
				continue;
			}
			if (abs((game[2][i]->get_bricky() - 10) - pad_height) <= 3) // Whether the power-up and paddle's y-cor match
			{
				if ((game[2][i]->get_brickx() >= game[1][0]->get_padx()) && (game[2][i]->get_brickx() <= (game[1][0]->get_padx() + game[1][0]->get_pad_l())))
				{
					Bricks *temp = dynamic_cast<Bricks *>(game[2][i]); // to convert it back into brick so we can access brick's functions and data members directly
					int pwr_type = (temp->brick_pwr).get_pwr_type();

					if (pwr_type == 1) // power type 1 i.e longer paddle
					{
						for (int k = 0; k < amount_pad; k++)
						{
							game[1][k]->set_pad_l(game[1][k]->get_pad_l() * 1.5);
						}
					}
					else if (pwr_type == 2) // half the paddle
					{
						for (int k = 0; k < amount_pad; k++)
						{
							game[1][k]->set_pad_l(game[1][k]->get_pad_l() / 1.5);
						}
					}
					else if (pwr_type == 3) // slows down ball
					{
						game[0][0]->set_ball_speed(game[0][0]->get_ball_speed() - 3);
					}
					else if (pwr_type == 4) // fastens up the ball
					{
						game[0][0]->set_ball_speed(game[0][0]->get_ball_speed() + 3);
					}
					else if (pwr_type == 5) // Multiplies the ball
					{
						// game[0][0]->set_ball_speed(game[0][0]->get_ball_speed() - 3);
					}

					Game::set_effect(pwr_type - 1, 1);
				}
			}
		}

		// show lives
		for (int i = 0; i < Game::lives; i++)
		{
			DrawCircle((16 * i) + 20 * i + 20, 650, 8, colors[RED]);
		}

		// if (broken == 0)
		// {
		// 	std::cout << "Here\n";

		// 	Game G; // temp object to simply call the function
		// 	G.game_setup(game, Game::level + 1); // change the level
		// }

		if (game[0][0]->get_bally() >= 600)
		{
			if (Game::level != 3)
			{
				direction_y = true;
			}
			else
			{
				Game::lives--;
				game[0][0]->set_ballx(350);
				game[0][0]->set_bally(140);
			}
		}

		// Collision between ball and lower paddle
		if (abs((game[0][0]->get_bally() - 8) - (game[1][0]->get_pady() + game[0][0]->get_pad_w())) <= 3) // using some range
		{
			// checking if their y-cor is the same (nearly)
			if (game[0][0]->get_ballx() >= game[1][0]->get_padx() && (game[0][0]->get_ballx() <= (game[1][0]->get_padx() + game[1][0]->get_pad_l())))
			{
				// Calculating offset for change in x-direction
				direction_x = (game[0][0]->get_ballx() - (game[1][0]->get_padx() + game[1][0]->get_pad_l() / 2));
				direction_x /= 5; // To make it a smaller value

				// checking if it is above the paddle
				direction_y = (direction_y) ? (false) : (true);

				// since it has sit color changes
				game[1][0]->set_pad_color(game[0][0]->get_ball_color());
			}
		}

		// Collision between ball and upper paddle
		if (Game::level == 3)
		{
			if (abs((game[0][0]->get_bally() + 8) - game[1][1]->get_pady()) <= 3) // using some range
			{
				// checking if their y-cor is the same (nearly)
				if (game[0][0]->get_ballx() >= game[1][1]->get_padx() && (game[0][0]->get_ballx() <= (game[1][1]->get_padx() + game[1][1]->get_pad_l())))
				{
					// Calculating offset for change in x-direction
					direction_x = (game[0][0]->get_ballx() - (game[1][1]->get_padx() + game[1][1]->get_pad_l() / 2));
					direction_x /= 5; // To make it a smaller value

					// checking if it is above the paddle
					direction_y = (direction_y) ? (false) : (true);

					// since it has sit color changes
					game[1][1]->set_pad_color(game[0][0]->get_ball_color());
				}
			}
		}

		// If it hits either side boundaries it changes it's x-direction
		if (game[0][0]->get_ballx() >= 792 || game[0][0]->get_ballx() <= 8)
		{
			direction_x = -direction_x;
		}

		if (game[0][0]->get_bally() <= 2)
		{
			game[0][0]->set_bally(40);
			game[0][0]->set_ballx(400);
			Game::set_game_lives(Game::lives - 1);
			direction_y = false;
		}

		if (Game::lives == 0 || Game::blocks == 0)
		{
			Game::game_started = 3;
		}

		game[0][0]->set_ballx(game[0][0]->get_ballx() + direction_x); // To continuously change the x-cor of ball

		// Ball and Brick Collision
		for (int i = 0; i < amount_brick; i++)
		{
			if (game[2][i]->get_brick_lives() == 0)
			{
				continue;
			}
			else if ((game[0][0]->get_bally() >= game[2][i]->get_bricky()) &&
					 (game[0][0]->get_bally() <= (game[2][i]->get_bricky() + game[2][i]->get_brick_w())))
			{ // if the y-cor of ball is either greater than or equal to the y-cor of brick
				// and it is also smaller than or equal to the (y-cor of brick + width of brick)
				bool hit = false;

				if ((game[0][0]->get_ballx() >= game[2][i]->get_brickx()) &&
					(game[0][0]->get_ballx() <= (game[2][i]->get_brickx() + game[2][i]->get_brick_l())))
				{
					// if the x-cor of ball is greater than the x-cor of brick
					// and it is also smaller than the (x-cor of brick + length of brick)
					direction_y = (direction_y) ? (false) : (true); // if moving up then down and vise versa
					hit = true;
				}
				else if (abs(game[0][0]->get_ballx() - game[2][i]->get_brickx()) < 2 &&
						 abs(game[0][0]->get_ballx() - (game[2][i]->get_brickx() + game[2][i]->get_brick_l())) < 2)
				{
					// If it is hitting the sides
					direction_x = -direction_x; // if moving left then right and vise versa
					hit = true;
				}
				if (hit)
				{
					game[0][0]->set_ball_color(game[2][i]->get_brick_color());
					game[2][i]->set_brick_lives(game[2][i]->get_brick_lives() - 1); // subtract one life
					if (game[2][i]->get_brick_color() != 2)
					{
						game[2][i]->set_brick_color(game[2][i]->get_brick_color() - 2);
					}
					else
					{
						game[2][i]->set_brick_color(game[2][i]->get_brick_color() - 1);
					}
				}
				if (game[2][i]->get_brick_lives() == 0) // increment score by 10
				{
					--Game::blocks;
					Game::set_game_score(Game::score + 10);
				}
			}
		}

		// Whether the ball moves up or down
		if (direction_y) // direction_y is true so the ball moves down
		{
			game[0][0]->set_bally(game[0][0]->get_bally() - game[0][0]->get_ball_speed());
		}
		else
		{
			game[0][0]->set_bally(game[0][0]->get_bally() + game[0][0]->get_ball_speed());
		}
	}
	else if (Game::game_started == 2)
	{
		DrawString(400, 300, "PAUSED", colors[GHOST_WHITE]);
	}
	else if (Game::game_started == 3)
	{
		string str;

		DrawString(300, 300, "Score: ", colors[GHOST_WHITE]);
		DrawString(400, 300, to_string(Game::score), colors[GHOST_WHITE]);
		DrawString(300, 250, "High Score: ", colors[GHOST_WHITE]);

		if (Game::level == 1)
		{
			fstream file;
			file.open("level1.txt", ios::app);
			file.close();

			file.open("level1.txt", ios::in);

			file >> str;

			file.close();

			if (str == "")
			{
				str = "0";
			}

			if (Game::score > stoi(str))
			{
				file.open("level1.txt", ios::out);
				if (!file)
				{
					cerr << "File is not present\n";
					exit(1);
				}
				file << to_string(Game::score);
				file.close();

				str = to_string(Game::score);
			}
		}
		else if (Game::level == 2)
		{
			fstream file;
			file.open("level2.txt", ios::app);
			file.close();

			file.open("level2.txt", ios::in);

			file >> str;

			file.close();

			if (str == "")
			{
				str = "0";
			}

			if (Game::score > stoi(str))
			{
				file.open("level2.txt", ios::out);
				if (!file)
				{
					cerr << "File is not present\n";
					exit(1);
				}
				file << to_string(Game::score);
				file.close();

				str = to_string(Game::score);
			}
		}
		else if (Game::level == 3)
		{

			fstream file;
			file.open("level3.txt", ios::app);
			file.close();

			file.open("level3.txt", ios::in);

			file >> str;

			file.close();

			if (str == "")
			{
				str = "0";
			}

			if (Game::score > stoi(str))
			{
				file.open("level3.txt", ios::out);
				if (!file)
				{
					cerr << "File is not present\n";
					exit(1);
				}
				file << to_string(Game::score);
				file.close();

				str = to_string(Game::score);
			}
		}
		DrawString(460, 250, str, colors[GHOST_WHITE]);
	}
	glutPostRedisplay();
	glutSwapBuffers(); // do not modify this line..
}

/*

This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
program coordinates of mouse pointer when key was pressed.

*/
void NonPrintableKeys(int key, int x, int y)
{
	if (Game::level == 3)
	{
		if (key == GLUT_KEY_LEFT)
		{
			game[1][1]->set_padx(game[1][1]->get_padx() - 20);
		}
		else if (key == GLUT_KEY_RIGHT)
		{
			game[1][1]->set_padx(game[1][1]->get_padx() + 20);
		}
	}
	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();
}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y)
{
	if (key == 27 /* Escape key ASCII*/)
	{
		exit(1); // exit the program when escape key is pressed.
	}
	if (Game::game_started != 2)
	{
		if (key == '1')
		{
			Game::game_started = 1;
			Game::blocks = 40;

			// Reading highscore
			string str;
			fstream file;
			file.open("level1.txt", ios::app);
			file.close();

			file.open("level1.txt", ios::in);

			file >> str;

			file.close();

			if (str == "")
			{
				str = "0";
			}

			Game::h_score = stoi(str);

			Game G(3);

			G.game_setup(game, 1); // Setting up the game as well as allocating all the space
		}
		if (key == '2')
		{
			Game::game_started = 1;
			Game::blocks = 18;
			Game G(3);

			// Reading highscore
			string str;
			fstream file;
			file.open("level2.txt", ios::app);
			file.close();

			file.open("level2.txt", ios::in);

			file >> str;
 
			file.close();

			if (str == "")
			{
				str = "0";
			}

			Game::h_score = stoi(str);

			G.game_setup(game, 2); // Setting up the game as well as allocating all the space
		}
		if (key == '3')
		{
			Game::game_started = 1;

			Game::blocks = 20;
			Game G(3);

			// Reading highscore
			string str;
			fstream file;
			file.open("level3.txt", ios::app);
			file.close();

			file.open("level3.txt", ios::in);

			file >> str;

			file.close();

			if (str == "")
			{
				str = "0";
			}

			Game::h_score = stoi(str);

			G.game_setup(game, 3); // Setting up the game as well as allocating all the space
		}
	}
	if (key == 'P' || key == 'p') // Pause
	{
		if (Game::game_started == 2)
		{
			Game::game_started = 1;
		}
		else if (Game::game_started == 1)
		{
			Game::game_started = 2;
		}
	}

	if (key == 'b' || key == 'B') // Key for placing the bomb
	{
		// do something if b is pressed
		cout << "b pressed" << endl;
	}
	glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m)
{
	int amount_pad = (Game::level == 1 || Game::level == 2) ? (1) : (2);
	// implement your functionality here
	static int check_effect[5] = {0, 0, 0, 0, 0};

	for (int i = 0; i < 5; i++)
	{
		if (Game::effects[i] == 1) // if a certain effect is present
		{
			check_effect[i]++;
		}
		if (check_effect[i] == 5) // if the ceratin effect is going on for 5 seconds
		{
			check_effect[i] = 0;
			Game::set_effect(i, 0);
			switch (i)
			{
			case 0:
				for (int i = 0; i < amount_pad; i++)
				{
					game[1][i]->set_pad_l(80);
				}
				break;
			case 1:
				for (int i = 0; i < amount_pad; i++)
				{
					game[1][i]->set_pad_l(80);
				}
				break;
			case 2:
				game[0][0]->set_ball_speed(5);
				break;
			case 3:
				game[0][0]->set_ball_speed(5);
				break;
			case 4:
				break;
			}
		}
	}

	// once again we tell the library to call our Timer function after next 1000/FPS
	glutPostRedisplay();
	glutTimerFunc(1000.0, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y)
{
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y)
{
	game[1][0]->set_padx(x - game[1][0]->get_pad_l() / 2);
	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y)
{

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
	{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;
	}
	else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
	{
		cout << "Right Button Pressed" << endl;
	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */

int main(int argc, char *argv[])
{
	srand(time(NULL));

	int row = 3;
	Game G(row);

	G.game_setup(game, 2); // Setting up the game as well as allocating all the space
	Game::blocks = 18;

	int width = 800, height = 700; // i have set my window size to be 800 x 600

	InitRandomizer();							  // seed the random number generator...
	glutInit(&argc, argv);						  // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50);				  // set the initial position of our window
	glutInitWindowSize(width, height);			  // set the size of our window
	glutCreateWindow("OOP Project");			  // set the title of our game window
	SetCanvasSize(width, height);				  // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	// glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay);	   // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys);   // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved);	  // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* AsteroidS_CPP_ */