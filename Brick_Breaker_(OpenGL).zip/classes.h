#include "util.h"
#include <iostream>
#include <string>
#include <cmath> // for basic math functions such as cos, sin, sqrt

using namespace std;

class Game;   // Parent class
class Ball;   // Child Classes
class Paddle; // Child Classes
class Bricks; // Child Classes

class Game
{
protected:
    int rows;

public:
    static int level;
    static int effects[5];
    static int lives;
    static int score;
    static int game_started;
    static int blocks;
    static int h_score;

    Game() {}
    Game(int r) : rows(r) {}

    // Setters
    static void set_level(int l) { level = l; }
    static void set_effect(int index, int val) { effects[index] = val; }
    static void set_game_lives(int l) { Game::lives = l; }
    static void set_game_score(int s) { score = s; }

    // Getters

    // Virtual functions
    virtual void setup(int num);

    virtual void set_padx(int x);
    virtual void set_pady(int y);
    virtual void set_pad_l(int l);
    virtual void set_pad_color(int c){};

    virtual int get_padx() const;
    virtual int get_pady() const;
    virtual int get_pad_l() const;
    virtual int get_pad_w() const;
    virtual int get_pad_color() const { return 1; }

    virtual void set_ballx(int x);
    virtual void set_bally(int y);
    virtual void set_ball_speed(int s){};
    virtual void set_ball_color(int c){};

    virtual int get_ballx() const;
    virtual int get_bally() const;
    virtual int get_ball_speed() const { return 1; }
    virtual int get_ball_color() const { return 1; }

    virtual void set_brickx(int x);
    virtual void set_bricky(int y);
    virtual void set_brick_lives(int l) {}
    virtual void set_brick_color(int c) {}

    virtual int get_brickx() const;
    virtual int get_bricky() const;
    virtual int get_brick_lives() const;
    virtual int get_brick_drop() const;
    virtual int get_brick_l() const { return 1; }
    virtual int get_brick_w() const { return 1; }
    virtual bool drop_pwr() { return 0; }
    virtual int get_brick_color() { return 1; }

    // Utility functions
    void initial_lvl1(Game ***&main, int &row, int l);
    void initial_lvl2(Game ***&main, int &row, int l);
    void initial_lvl3(Game ***&main, int &row, int l);
    void dealloc(Game ***&main);
    void game_setup(Game ***&main, int l);
};

int Game::level = 1;
int Game::effects[5] = {0, 0, 0, 0, 0};
int Game::score = 0;
int Game::lives = 3;
int Game::game_started = 0;
int Game::blocks = 0;
int Game::h_score = 0;

// Ball Class
class Ball : public Game
{
private:
    int ballx;
    int bally;
    int ball_r = 5;
    int speed = 5;
    int ball_color = 0;

public:
    Ball() {}
    Ball(int x, int y);

    void setup(int num);

    // Setters and Getters
    void set_ballx(int x);
    void set_bally(int y);
    void set_ball_speed(int s) { speed = s; }
    void set_ball_color(int c) { ball_color = c; }

    int get_ballx() const;
    int get_bally() const;
    int get_ball_speed() const { return speed; }
    int get_ball_color() const { return ball_color; }
};

// Paddle Class
class Paddle : public Game
{
private:
    int padx;
    int pady;
    int pad_w = 5;
    int pad_l;
    int pad_color = 0;

public:
    Paddle() {}
    Paddle(int x, int y, int l = 40);

    void setup(int num);

    // Setters and Getters
    void set_padx(int x);
    void set_pady(int y);
    void set_pad_l(int l);
    void set_pad_color(int c) { pad_color = c; }

    int get_padx() const;
    int get_pady() const;
    int get_pad_l() const;
    int get_pad_w() const;
    int get_pad_color() const { return pad_color; }
};

class Power
{
private:
    int pwr_x;
    int pwr_y;
    int type; // 1. Longer Paddle , 2. Fast ball
public:
    Power() {}
    Power(int x, int y, int t) : pwr_x(x), pwr_y(y), type(t) {}
    // Getters
    int get_pwr_x() { return pwr_x; }
    int get_pwr_y() { return pwr_y; }
    int get_pwr_type() { return type; }

    // Setters
    void set_pwr_x(int x) { pwr_x = x; }
    void set_pwr_y(int y) { pwr_y = y; }
    void set_pwr_type(int t) { type = t; }
};

// Bricks Class
class Bricks : public Game
{
private:
    int brickx;
    int bricky;
    int brick_w;
    int brick_l;
    int lives;
    int drop;
    int color;

public:
    Power brick_pwr;

    Bricks() {}
    Bricks(int x, int y, int l, int d);

    void setup(int num);

    // Setters and Getters
    void set_brickx(int x);
    void set_bricky(int y);
    void set_brick_lives(int l);
    void set_brick_color(int c) { color = c; }

    int get_brickx() const;
    int get_bricky() const;
    int get_brick_lives() const;
    int get_brick_drop() const;
    int get_brick_l() const;
    int get_brick_w() const;
    int get_brick_powers() { return brick_pwr.get_pwr_type(); }
    int get_brick_color() { return color; }

    // Util
    bool drop_pwr()
    {
        if (brick_pwr.get_pwr_type() != 0)
        {
            return true;
        }
        return false;
    }

    static void level_set_3(Bricks *&arr, int size, int help = 0)
    {
        if (help >= 20)
        {
            return;
        }
        if (help >= 0 && help <= 4)
        {
            arr[help].brickx = (80 * help) + 200;
            arr[help].bricky = 360;
        }
        else if (help >= 5 && help <= 6)
        {
            arr[help].brickx = arr[help - 5].brickx;
            arr[help].bricky = 320;
        }
        else if (help >= 7 && help <= 8)
        {
            arr[help].brickx = arr[help - 4].brickx;
            arr[help].bricky = 320;
        }
        else if (help == 9)
        {
            arr[help].brickx = 200;
            arr[help].bricky = 280;
        }
        else if (help == 10)
        {
            arr[help].brickx = 520;
            arr[help].bricky = 280;
        }
        else if (help >= 11 && help <= 12)
        {
            arr[help].brickx = arr[help - 11].brickx;
            arr[help].bricky = 240;
        }
        else if (help >= 13 && help <= 14)
        {
            arr[help].brickx = arr[help - 10].brickx;
            arr[help].bricky = 240;
        }
        else if (help >= 15 && help <= 19)
        {
            arr[help].brickx = arr[help - 15].brickx;
            arr[help].bricky = 200;
        }

        arr[help].lives = rand() % 3 + 1;
        arr[help].drop = rand() % 4 + 1;

        if (arr[help].lives == 2)
        {
            arr[help].color = rand() % 2 + 1;
        }
        else if (arr[help].lives == 1)
        {
            arr[help].color = 0;
        }
        else
        {
            arr[help].color = 3;
        }

        arr[help].brick_l = 80;
        arr[help].brick_w = 40;

        (arr[help].brick_pwr).set_pwr_x(arr[help].brickx);
        (arr[help].brick_pwr).set_pwr_y(arr[help].bricky);

        if (arr[help].drop == 1 || arr[help].drop == 2)
        {
            (arr[help].brick_pwr).set_pwr_type(rand() % 5 + 1);
        }
        else
        {
            (arr[help].brick_pwr).set_pwr_type(0);
        }

        level_set_3(arr, 20, ++help);
    }
};

// Game Class Function Definitions

void Game::setup(int num) {}
void Game::set_padx(int x) {}
void Game::set_pady(int y) {}
void Game::set_pad_l(int l) {}

int Game::get_padx() const { return 1; }
int Game::get_pady() const { return 1; }
int Game::get_pad_l() const { return 1; }
int Game::get_pad_w() const { return 1; }

void Game::set_ballx(int x) {}
void Game::set_bally(int y) {}

int Game::get_ballx() const { return 1; }
int Game::get_bally() const { return 1; }

void Game::set_brickx(int x) {}
void Game::set_bricky(int y) {}

int Game::get_brickx() const { return 1; }
int Game::get_bricky() const { return 1; }
int Game::get_brick_lives() const { return 1; }
int Game::get_brick_drop() const { return 1; }

void Game::initial_lvl1(Game ***&main, int &row, int l) // l = level
{
    if (main == nullptr)
    {
        main = new Game **[rows];
    }

    Ball *balls = new Ball[1];
    Paddle *paddle = new Paddle[1];
    Bricks *bricks = new Bricks[40];

    main[0] = new Game *[1];
    main[1] = new Game *[1];
    main[2] = new Game *[40];

    for (int i = 0; i < 1; i++)
    {
        main[0][i] = &balls[i];
        (main[0])[i]->setup(i);
    }

    for (int i = 0; i < 1; i++)
    {
        main[1][i] = &paddle[i];
        (main[1])[i]->setup(i);
    }

    for (int i = 0; i < 40; i++)
    {
        main[2][i] = &bricks[i];
        (main[2])[i]->setup(i);
    }
}

void Game::initial_lvl2(Game ***&main, int &row, int l)
{
    // dealloc(main);

    if (main == nullptr)
    {
        main = new Game **[rows];
    }

    Ball *balls = new Ball[1];
    Paddle *paddle = new Paddle[1];
    Bricks *bricks = new Bricks[18];

    main[0] = new Game *[1];
    main[1] = new Game *[1];
    main[2] = new Game *[18];

    for (int i = 0; i < 1; i++)
    {
        main[0][i] = &balls[i];
        (main[0])[i]->setup(i);
    }

    for (int i = 0; i < 1; i++)
    {
        main[1][i] = &paddle[i];
        (main[1])[i]->setup(i);
    }

    for (int i = 0; i < 18; i++)
    {
        main[2][i] = &bricks[i];
        (main[2])[i]->setup(i);
    }
}

void Game::initial_lvl3(Game ***&main, int &row, int l)
{

    // dealloc(main, row, l);

    if (main == nullptr)
    {
        main = new Game **[rows];
    }

    Ball *balls = new Ball[1];
    Paddle *paddle = new Paddle[2];
    Bricks *bricks = new Bricks[20];

    Bricks::level_set_3(bricks, 20);

    main[0] = new Game *[1];
    main[1] = new Game *[2];
    main[2] = new Game *[20];

    for (int i = 0; i < 1; i++)
    {
        main[0][i] = &balls[i];
        (main[0])[i]->setup(i);
    }

    for (int i = 0; i < 2; i++)
    {
        main[1][i] = &paddle[i];
        (main[1])[i]->setup(i);
    }

    for (int i = 0; i < 20; i++)
    {
        main[2][i] = &bricks[i];
    }
}

void Game::dealloc(Game ***&main)
{
    if (main == nullptr)
    {
        return;
    }
    for (int i = 0; i < 3; i++)
    {
        if (main[i] != nullptr)
        {
            delete[] main[i];  // Delete each inner array
            main[i] = nullptr; // Set to nullptr to avoid dangling pointers
        }
    }
    delete[] main;
    main = nullptr;
}

void Game::game_setup(Game ***&main, int l)
{
    if (main != nullptr)
    {
        dealloc(main);
    }
    if (main == nullptr)
    {
        main = new Game **[rows];
    }
    switch (l)
    {
    case 1:
        initial_lvl1(main, rows, l);
        break;
    case 2:
        initial_lvl2(main, rows, l);
        break;
    case 3:
        initial_lvl3(main, rows, l);
        break;
    }

    Game::level = l;
}

// Ball Class Function Definitions
Ball::Ball(int x, int y) : ballx(x), bally(y) {}

void Ball::setup(int num)
{
    ballx = 350;
    bally = 40;
}

void Ball::set_ballx(int x) { ballx = x; }
void Ball::set_bally(int y) { bally = y; }

int Ball::get_ballx() const { return ballx; }
int Ball::get_bally() const { return bally; }

// Paddle Class Function Definitions
Paddle::Paddle(int x, int y, int l) : padx(x), pady(y), pad_l(l) {}

void Paddle::setup(int num)
{
    if (level == 1 || level == 2)
    {
        padx = 400;
        pady = 20;
        pad_l = 80;
        pad_w = 10;
    }
    else if (level == 3)
    {
        std::cout << num << ' ';
        if (num == 0)
        {
            padx = 400;
            pady = 20;
            pad_l = 80;
            pad_w = 10;
        }
        else
        {
            padx = 350;
            pady = 580;
            pad_l = 80;
            pad_w = 10;
        }
    }
}

void Paddle::set_padx(int x) { padx = x; }
void Paddle::set_pady(int y) { pady = y; }
void Paddle::set_pad_l(int l) { pad_l = l; }

int Paddle::get_padx() const { return padx; }
int Paddle::get_pady() const { return pady; }
int Paddle::get_pad_l() const { return pad_l; }
int Paddle::get_pad_w() const { return pad_w; }

// Bricks Class Function Definitions
Bricks::Bricks(int x, int y, int l, int d) : brickx(x), bricky(y), lives(l), drop(d) {}

void Bricks::setup(int num)
{
    // std::cout << num << ' ';
    if (level == 1)
    {
        int helper = num % 10;

        brickx = 80 * helper;
        bricky = 560 - ((num / 10) * 40);

        lives = rand() % 3 + 1;

        if (lives == 2)
        {
            color = rand() % 2 + 1;
        }
        else if (lives == 1)
        {
            color = 0;
        }
        else
        {
            color = 3;
        }

        drop = rand() % 4 + 1;

        brick_l = 80;
        brick_w = 40;

        brick_pwr.set_pwr_x(brickx);
        brick_pwr.set_pwr_y(bricky);

        if (drop == 1 || drop == 2)
        {
            brick_pwr.set_pwr_type(rand() % 5 + 1);
        }
        else
        {
            brick_pwr.set_pwr_type(0);
        }
    }
    else if (level == 2)
    {
        int spaces = 80;

        if (0 <= num && num < 10)
        {
            brickx = spaces * num;
            if (0 <= num && num <= 1)
            {
                bricky = 560 - 40;
            }
            else if (2 <= num && num <= 3)
            {
                bricky = 560 - 80;
            }
            else if (4 <= num && num <= 5)
            {
                bricky = 560 - 120;
            }
            else if (6 <= num && num <= 7)
            {
                bricky = 560 - 160;
            }
            else if (8 <= num && num <= 9)
            {
                bricky = 560 - 200;
            }
        }
        else
        {
            brickx = spaces * (17 - num);
            if (10 <= num && num <= 11)
            {
                bricky = 360 - 40;
            }
            else if (12 <= num && num <= 13)
            {
                bricky = 360 - 80;
            }
            else if (14 <= num && num <= 15)
            {
                bricky = 360 - 120;
            }
            else if (16 <= num && num <= 17)
            {
                bricky = 360 - 160;
            }
            else if (18 <= num && num <= 19)
            {
                bricky = 360 - 200;
            }
        }

        lives = rand() % 3 + 1;
        drop = rand() % 4 + 1;

        brick_l = 80;
        brick_w = 40;

        brick_pwr.set_pwr_x(brickx);
        brick_pwr.set_pwr_y(bricky);

        if (lives == 2)
        {
            color = rand() % 2 + 1;
        }
        else if (lives == 1)
        {
            color = 0;
        }
        else
        {
            color = 3;
        }

        if (drop == 1 || drop == 2)
        {
            brick_pwr.set_pwr_type(rand() % 5 + 1);
        }
        else
        {
            brick_pwr.set_pwr_type(0);
        }
    }
}

void Bricks::set_brickx(int x) { brickx = x; }
void Bricks::set_bricky(int y) { bricky = y; }
void Bricks::set_brick_lives(int l) { lives = l; }

int Bricks::get_brickx() const { return brickx; }
int Bricks::get_bricky() const { return bricky; }
int Bricks::get_brick_lives() const { return lives; }
int Bricks::get_brick_drop() const { return drop; }
int Bricks::get_brick_l() const { return brick_l; }
int Bricks::get_brick_w() const { return brick_w; }
