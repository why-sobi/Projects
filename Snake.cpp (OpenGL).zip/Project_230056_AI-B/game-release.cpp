
#ifndef TETRIS_CPP_
#define TETRIS_CPP_
#include "util.h"
#include <iostream>
#include<vector>
#include<algorithm>
//#include<cstdlib>
#include<ctime>
#include<string>
//#include<sys/wait.h>
//#include<stdlib.h>
//#include<stdio.h>
#include<unistd.h>
#include<sstream>
#include<cmath> 
#include<fstream> 
using namespace std;

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
    glMatrixMode( GL_MODELVIEW);
    glLoadIdentity();
}


/*
 * Main Canvas drawing function.
 * */
 
 //Global Variables
int startx=150,starty=360;
int sqX=startx,sqY=starty-7;
int score=0;
int finalscore;
int bestscore;
int snake_len = 3;
char direction;
int ballx1=280;
int bally1=110;
int ballx2=520;
int bally2=360;
int ballx3=190;
int bally3=340;
int ballx4=550;
int bally4=420;
int ballx5=630;
int bally5=170;
int bigSnackx1=600;
int bigSnacky1=700;
int bigSnackx2=550;
int bigSnacky2=700;
int bodyX[100];
int bodyY[100];
int ball1Time=0;
int ball2Time=0;
int ball3Time=0;
int ball4Time=0;
int ball5Time=0;
int bigSnack_1_Count=0;
int bigSnack_2_Count=0;
int obstacle_20_secCount=0;
int obstacle_type;
int obsX1_line;
int obsY1_line;
int obsX2_line;
int obsY2_line;
int obsX1_line2;
int obsY1_line2;



void obstacle()
{
	++obstacle_20_secCount;
	if(obstacle_20_secCount==500 || obstacle_20_secCount==1000)
	{	
		if(obstacle_20_secCount==500)
		{
			obstacle_type=(rand()%4)+1;
			switch(obstacle_type)
			{
				case 1:	
					obsX1_line=(rand()%649)+1;
					obsY1_line=obsX1_line;
					obsX2_line=obsX1_line+50;
					obsY2_line=obsY1_line;
					obsX1_line2=obsX1_line;
					obsY1_line2=obsY1_line+50;
					break;
				case 2:
					obsX1_line=(rand()%649)+1;
					obsY1_line=obsX1_line;
					obsX2_line=obsX1_line-50;
					obsY2_line=obsY1_line;
					obsX1_line2=obsX1_line;
					obsY1_line2=obsY1_line-50;
					break;
				case 3:
					obsX1_line=(rand()%649)+1;
					obsY1_line=obsX1_line;
					obsX2_line=obsX1_line-50;
					obsY2_line=obsY1_line;
					obsX1_line2=obsX1_line;
					obsY1_line2=obsY1_line+50;
					break;
				case 4:
					obsX1_line=(rand()%649)+1;
					obsY1_line=obsX1_line;
					obsX2_line=obsX1_line+50;
					obsY2_line=obsY1_line;
					obsX1_line2=obsX1_line;
					obsY1_line2=obsY1_line-50;
					break;
			}
		}
		else 
		{
			obsX1_line=0;
			obsY1_line=0;
			obsX2_line=0;
			obsY2_line=0;
			obsX1_line2=0;
			obsY1_line2=0;
			obstacle_20_secCount=0;
		}
	}
}

int highest_score()
{
	int highestscore=0; //retreiving highest score
	ifstream file("highest_score.txt");
	if(file.is_open())
	{
		file >> highestscore;
		file.close();
	}
	return highestscore;
}
int scoreUpdate(int x)
{
	int highestscore=highest_score();
	if(x>highestscore) //comparing score
	{
		highestscore=x;
		ofstream file("highest_score.txt");
		if(file.is_open())
		{
			file<<x;
			file.close();
		}
	
	}
	return highestscore;
}

void foodCoordinates()
{	//spawning of food and score increase
	++ball1Time;
	++ball2Time;
	++ball3Time;
	++ball4Time;
	++ball5Time;
	++bigSnack_1_Count;
	++bigSnack_2_Count;
	srand(time(NULL));
	if((startx==ballx1 && starty==bally1) || ball1Time==2500)
	{
		if( ball1Time!=2500)
		{
			score+=5;
			++snake_len;
		}
		else
		{
			ball1Time=0;
		}
			ballx1=(rand()%649)+1;
			bally1=(rand()%649)+1;
		while(true)
		{
			ballx1=(rand()%649)+1;
			bally1=(rand()%649)+1;
			if(ballx1%5==0 && bally1%5==0 && ballx1!=ballx2 && ballx1!=ballx3 && ballx1!=ballx4 && ballx1!=ballx5 && bally1!=bally2 &&  bally1!=bally3 &&  bally1!=bally4 &&  bally1!=bally5 && ballx1/bally1!=1 && (ballx1+bally1)!=(ballx1*2))
			{
				break;
			}
		}
	}
	if((startx==ballx2 && starty==bally2) || ball2Time==2500)
	{
		if(ball2Time!=3750)
		{
			score+=5;
			++snake_len;
		}
		else
		{
			ball2Time=0;
		}
		while(true)
		{	
			ballx2=(rand()%649)+1;
			bally2=(rand()%649)+1;
			if(ballx2%5==0 && bally2%5==0 && ballx1!=ballx2 && ballx2!=ballx3 && ballx2!=ballx4 && ballx2!=ballx5 && bally1!=bally2 &&  bally2!=bally3 &&  bally2!=bally4 &&  bally2!=bally5 && ballx2/bally2!=1 && (ballx2+bally2)!=(ballx2*2))
			{
				break;
			}
		}
	}
	if((startx==ballx3 && starty==bally3) || ball3Time==2500)
	{
		if(ball3Time!=2500)
		{
			score+=5;
			++snake_len;
		}
		else
		{
			ball3Time=0;
		}
		while(true)
		{	
			ballx3=(rand()%649)+1;
			bally3=(rand()%649)+1;
			if(ballx3%5==0 && bally3%5==0 && ballx3!=ballx2 && ballx1!=ballx3 && ballx3!=ballx4 && ballx3!=ballx5 && bally1!=bally3 &&  bally3!=bally4 &&  bally3!=bally5 && ballx3/bally3!=1 && (ballx3+bally3)!=(ballx3*2))
			{
				break;
			}
		}
	}
	if((startx==ballx5 && starty==bally5) || ball5Time==2500)
	{
		if(ball5Time!=2500)
		{
			score+=5;
			++snake_len;
		}
		else
		{
			ball5Time=0;
		}
		while(true)
		{	
			ballx5=(rand()%649)+1;
			bally5=(rand()%649)+1;
			if(ballx5%5==0 && bally5%5==0 && ballx5!=ballx2 && ballx5!=ballx3 && ballx5!=ballx4 && ballx1!=ballx5 && bally5!=bally2 &&  bally5!=bally3 &&  bally5!=bally4  && ballx5/bally5!=1 && (ballx5+bally5)!=(ballx5*2))
			{
				
					break;
			}
		}
	}
	if((startx==ballx4 && starty==bally4) || ball4Time==2500)
	{
		if(ball4Time!=2500)
		{
			score+=5;
			++snake_len;
		}
		else
		{
			ball4Time=0;
		}
		while(true)
		{	
			ballx4=(rand()%649)+1;
			bally4=(rand()%649)+1;
			if(ballx4%5==0 && bally4%5==0 && ballx4!=ballx2 && ballx4!=ballx3 && ballx1!=ballx4 && ballx4!=ballx5 && bally4!=bally2 &&  bally4!=bally3 && ballx4/bally4!=1 && (ballx4+bally4)!=(ballx4*2))
			{
				break;
			}
		}
	}
	
	if((startx==bigSnackx1 && starty==bigSnacky1) || bigSnack_1_Count==1500)
	{
		if(bigSnack_1_Count!=1500)
		{
			score+=20;
			++snake_len;
			bigSnackx1=600;
			bigSnacky1=700;
		}
		else if (bigSnack_1_Count==1500 && (bigSnackx1==600 && bigSnacky1==700))
		{
			bigSnack_1_Count=0;
			while(true)
			{		
				bigSnackx1=(rand()%649)+1;
				bigSnacky1=(rand()%649)+1;
				if(bigSnackx1%5==0 && bigSnacky1%5==0)
				{
					break;
				}
			}
		}
		else if (bigSnack_1_Count==1500 && (bigSnackx1!=600 && bigSnacky1!=700)) 
		{
			bigSnack_1_Count=0;
			bigSnackx1=600;
			bigSnacky1=700;
		}
		
		
	}
	if((startx==bigSnackx2 && starty==bigSnacky2) || bigSnack_2_Count==1500)
	{
		if(bigSnack_2_Count!=1500)
		{
			score+=20;
			++snake_len;
			bigSnackx2=550;
			bigSnacky2=700;
			
		}
		else if (bigSnack_2_Count==1500 && (bigSnackx2==550 && bigSnacky2==700))
		{
			bigSnack_2_Count=0;
			while(true)
			{	
				bigSnackx2=(rand()%649)+1;
				bigSnacky2=(rand()%649)+1;
				if(bigSnackx2%5==0 && bigSnacky2%5==0)
				{
					break;
				}
			}
		}
		else if (bigSnack_2_Count==1500 && (bigSnackx2!=550 && bigSnacky2!=700)) 
		{
			bigSnack_2_Count=0;
			bigSnackx2=550;
			bigSnacky2=700;
		}
		
	}
}
void gameoverCheck() // conditions to check if the game is over
{
	if(starty<=0 || starty>=650)
	{
		direction = 'E';
	}
	else if ((startx<=0 || startx>=650 ) && (starty<=240 || starty>=390))
	{
		direction = 'E';
	}
	else
		for(int i = 0 ; i < snake_len ; ++i)
		{
			if (bodyX[i]==startx || bodyX[i]==starty)
			{
				direction='E';
				break;
			}
			else if (bodyY[i]==startx || bodyY[i]==starty)
			{
				direction='E';
				break;
			}
		}
	if(score>100)
	{
	if ((starty == 160) && (startx <= 160 && startx >= 60))
	{
		direction='E';
	}
	else if ((startx == 160) && (starty <= 160 && starty >= 60))
	{
		direction='E';
	}
	else if ((starty == 490) && (startx >= 60 && startx <= 160))
	{
		direction='E';
	}
	else if ((startx == 160) && (starty <= 590 && starty >= 490))
	{
		direction='E';
	}
	else if ((starty == 490) && (startx >= 490 && startx <= 590))
	{
		direction='E';
	}
	else if ((startx == 490) && (starty >= 490 && starty <= 590))
	{
		direction='E';
	}
	else if ((startx == 490) && (starty <= 160 && starty >= 60))
	{
		direction='E';
	}
	else if ((starty == 160) && (startx >= 490 && startx <= 590))
	{
		direction='E';
	}
	if(score>250)
	{
		if(startx>=650 || startx<=0)
		{
			direction = 'E';
		}
		else if (starty>=650 || starty<=0)
		{
			direction = 'E';
		}
		else if ((starty==325)&&(startx<=434 && startx>=216))
		{
			direction='E';
		}
		else if ((startx==325)&&(starty<=434 && starty>=216))
		{
			direction='E';
		}
	}
	}
	switch(obstacle_type)
	{
		case 1:	
			if((startx==obsX1_line)&&(starty<=obsY1_line2 && starty>=obsY1_line))
				direction='E';
			else if((starty==obsY1_line)&&(startx<=obsX2_line && startx>=obsX1_line))
				direction='E';
			break;
		case 2:
			if((startx==obsX1_line)&&(starty<=obsY1_line && starty>=obsY1_line2))
				direction='E';
			else if((starty==obsY1_line)&&(startx<=obsX1_line && startx>=obsX2_line))
				direction='E';
			break;
		case 3:
			if((startx==obsX1_line)&&(starty<=obsY1_line2 && starty>=obsY1_line))
				direction='E';
			else if((starty==obsY1_line)&&(startx<=obsX1_line && startx>=obsX2_line))
				direction='E';
			break;
		case 4:
			if((startx==obsX1_line)&&(starty<=obsY1_line2 && starty>=obsY1_line))
				direction='E';
			else if((starty==obsY1_line)&&(startx<=obsX2_line && startx>=obsX1_line))
				direction='E';
			break;
			}
}
void initializeArray()
{
	bodyX[0] = startx + 15;
	bodyY[0] = starty;
	
	bodyX[1] = bodyX[0] + 15;
	bodyY[1] = bodyY[0];
}
void Display() // displaying of the whole game
{
	srand(time(NULL));
	obstacle_20_secCount++;
    // set the background color using function glClearColotgr.

    glClearColor(0.0/*Red Component*/, 0.0/*Green Component*/,
            0.0/*Blue Component*/, 0.88 /*Alpha component*/);// Red==Green==Blue==1 --> White Colour
    glClear(GL_COLOR_BUFFER_BIT);   //Update the colors
    
    
    DrawString( 50, 700, "Score = ", colors[MISTY_ROSE]);
    DrawString( 130, 700, to_string(score), colors[MISTY_ROSE]);
    
    
    
    DrawCircle( startx , starty , 7.5 , colors[FOREST_GREEN]);//head
    
    
	for(int i = 0 ; i < snake_len ; ++i)
	{
    		DrawSquare( bodyX[i] , bodyY[i] ,16,colors[GREEN]);
    	} 
    	
    	
    	
    	if(score<=250)
    	{
      		if((240<starty&&starty<390)&&((startx>=650)))
      		{
      			startx=0;
      		}
      		else if((240<starty&&starty<390)&&((startx<=0)))
      		{
      			startx=650;
      		}
      	}					
	
	
	
   
    
    
    DrawCircle( ballx1 , bally1 , 7 , colors[5]);
    DrawCircle( ballx2 , bally2 , 7 , colors[5]);
    DrawCircle( ballx3 , bally3 , 7 , colors[5]);
    DrawCircle( ballx4 , bally4 , 7 , colors[5]);
    DrawCircle( ballx5 , bally5 , 7 , colors[5]);//snack
    DrawCircle( bigSnackx1 , bigSnacky1 , 10 , colors[5]);//bigG
    DrawCircle( bigSnackx2 , bigSnacky2 , 10 , colors[5]);

    
    
    
    
    if(score>100)
    {
    	DrawLine( 0 , 0 ,  0 , 240 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 390 ,  0 , 650 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 650 ,  650 , 650 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 0 ,  650 , 0 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 650 , 0 ,  650 , 240 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 650 , 390 ,  650 , 650 , 50 , colors[MISTY_ROSE] );
    	
    	DrawLine( 160 , 160 ,  60 , 160 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 160 , 160 ,  160 , 60 , 50 , colors[MISTY_ROSE] );
    	
    	DrawLine( 160 , 490 ,  60 , 490 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 160 , 490 ,  160 , 590 , 50 , colors[MISTY_ROSE] );
    	
    	DrawLine( 490 , 490 ,  590 , 490 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 490 , 490 ,  490 , 590 , 50 , colors[MISTY_ROSE] );
    	
    	DrawLine( 490 , 160 ,  590 , 160 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 490 , 160 ,  490 , 60 , 50 , colors[MISTY_ROSE] );
    	if(score>250)
    	{
    	DrawLine( 0 , 0 ,  0 , 650 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 650 ,  650 , 650 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 650 , 650 ,  650 , 0 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 0 ,  650 , 0 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 216 , 325 ,  434 , 325 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 325 , 434 ,  325 , 216 , 50 , colors[MISTY_ROSE] );
    	}
    }
    else if (score<=100)
    {
    	DrawLine( 0 , 0 ,  0 , 240 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 390 ,  0 , 650 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 650 ,  650 , 650 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 0 , 0 ,  650 , 0 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 650 , 0 ,  650 , 240 , 50 , colors[MISTY_ROSE] );
    	DrawLine( 650 , 390 ,  650 , 650 , 50 , colors[MISTY_ROSE] );
    }
    
    if(obstacle_20_secCount>=500 && obstacle_20_secCount<=1000)
    {
    	DrawLine( obsX1_line , obsY1_line ,  obsX2_line , obsY2_line , 50 , colors[MISTY_ROSE] );
    	DrawLine( obsX1_line , obsY1_line ,  obsX1_line2 , obsY1_line2 , 50 , colors[MISTY_ROSE] );
    }
    
    
    
    if(direction=='O')
    {
    	int displayscore = finalscore;
    	DrawString( 275, 375, "GAME OVER", colors[MISTY_ROSE]);
    	DrawString( 275, 350, "YOUR SCORE: ", colors[MISTY_ROSE]);
    	DrawString( 440, 350, to_string(displayscore), colors[MISTY_ROSE]);
    	DrawString( 275, 330, "HIGHEST SCORE: ", colors[MISTY_ROSE]);
    	DrawString( 480, 330, to_string(bestscore), colors[MISTY_ROSE]);
    	DrawString( 100, 300, "Press Escape to exit or press any arrow to play again", colors[MISTY_ROSE]);
    	
    	
    }
   glutSwapBuffers(); // do not modify this line..
}

void NonPrintableKeys(int key, int x, int y) // input for movement
{
    if (key == GLUT_KEY_LEFT) 
    {
    	if(direction!='D')
    	{
    		direction = 'A';
    		
    	} 	
    } 
    else if (key == GLUT_KEY_RIGHT) 
    {	
    	if(direction!='A')
    	{
    		direction = 'D';
    		
    	}		
    } 
    else if (key == GLUT_KEY_UP) 
    {
       
       if(direction!='S')
    	{
    		direction = 'W';
    		
    	}
    }
    else if (key == GLUT_KEY_DOWN)
    {   
    	if(direction!='W') 
    	{
    		direction = 'S';
		
	}
    }
    

    /* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
     * this function*/
     glutPostRedisplay();

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) // for external controls such as closing the game and restarting
{
    if (key == KEY_ESC/* Escape key ASCII*/) {
        exit(1); // exit the program when escape key is pressed.
    }
    if (key == 'R' || key=='r'/* Escape key ASCII*/) {
        ++snake_len; // exit the program when escape key is pressed.
    	//aswangle+=90;
    }
    
    else if (int(key) == 'B' || int(key) == 'b' )
    {  
	startx=110;
	starty=360;    
	score=0;
	sqX=startx;
	snake_len=3;
	sqY=353;	
	}
    
    glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */

void Timer(int m) //to call functions how many times and such
 {
	gameoverCheck();
	foodCoordinates();
	obstacle();
	for(int i = snake_len - 1 ; i > 0 ; --i)
	{
		bodyX[i]=bodyX[i-1];
		bodyY[i]=bodyY[i-1];
	}
	bodyX[0]=startx-7;
	bodyY[0]=starty-7;
	
// implement your functionality here
	glutPostRedisplay();
	switch(direction)
	{
		case 'A':
			startx-=5;	
    			break;
    		case 'D':
			startx+=5;
    			break;
    		case 'W':
			starty+=5;	
    			break;
    		case 'S':
			starty-=5;	
    			break;
    		case 'O':
    			break;
    		default:
    			startx=150;
    			starty=360;
    			snake_len=3;
    			finalscore=score;
    			bestscore=scoreUpdate(finalscore);
    			score=0;
    			direction='O';
    			
    			
	}
	
// once again we tell the library to call our Timer function after next 1000/FPS
    glutTimerFunc(250.0 / FPS, Timer, 0);
}

/*
 * our gateway main function
 * */
int main(int argc, char*argv[])
 {
	initializeArray();
    int width = 650, height = 750; // i have set my window size to be 800 x 600
    InitRandomizer(); // seed the random number generator...
    glutInit(&argc, argv); // initialize the graphics library...

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
    glutInitWindowPosition(50, 50); // set the initial position of our window
    glutInitWindowSize(width, height); // set the size of our window
    glutCreateWindow("PF's Snake Game"); // set the title of our game window
    SetCanvasSize(width, height); // set the number of pixels...

// Register your functions to the library,
// you are telling the library names of function to call for different tasks.
//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.
    glutDisplayFunc(Display); // tell library which function to call for drawing Canvas.
    glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
    glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
    glutTimerFunc(1000.0 / FPS, Timer, 0);

// now handle the control to library and it will call our registered functions when
// it deems necessary...
    glutMainLoop();
    return 1;
}

#endif /* Snake Game */

